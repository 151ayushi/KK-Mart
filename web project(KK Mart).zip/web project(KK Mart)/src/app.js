const express = require('express');
const path = require('path');
require('./db/conn');
const User = require('./models/usermessage')
const Login = require('./models/userlogin')
const hbs = require('hbs');
const app =express();

const port = process.env.PORT || 3030;

//setting path
const static_path = path.join(__dirname,'../public');
const template_path = path.join(__dirname,"../templates/views");
const partial_path = path.join(__dirname,"../templates/partials");


//middleware
app.use('/css',express.static(path.join(__dirname,'node_modules/bootstrap/dist/css')))
app.use('/js',express.static(path.join(__dirname,'node_modules/bootstrap/dist/js')))
app.use('/jq',express.static(path.join(__dirname,'node_modules/jquery/dist')))

app.use(express.json());

app.use(express.urlencoded({extended:false})); 
app.use(express.static(static_path));
app.set("view engine","hbs");
app.set("views",template_path);
hbs.registerPartials(partial_path);


//routing
app.get("/",(req,resp) => {
        resp.render("index");
});

app.get("/index",(req,resp) => {
        resp.render("index");
});

app.get("/contact" , (req,res) => {
        res.render("contact")
})

app.get("/about" , (req,res) => {
        res.render("about")
})

app.get("/product" , (req,res) => {
        res.render("product")
})

app.get("/login" , (req,res) => {
        res.render("login")
})




app.post("/contact",async(req,resp) => {
        try{
                //resp.send(req.body);
                const userData = new User(req.body);
                await userData.save();
                resp.status(201).render("index");
        }catch(error){
                resp.status(500).send(error); 
        }  
})
 

app.post("/login",async(req,resp) => {
        try{
                //resp.send(req.body);
                const loginData = new Login(req.body);
                await loginData.save();
                resp.status(201).render("index");
        }catch(error){
                resp.status(500).send(error); 
        }  
})
 
 

//server create 
//app.listen(3030);
app.listen(port,()=>{
        console.log(`server is running at port no ${port}`);
}) 