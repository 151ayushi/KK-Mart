const mongoose = require('mongoose');
const validator = require('validator');

 const userSchema = mongoose.Schema({
        
        email:{
                type:String,
                required:true,
                validate(value){
                        if(!validator.isEmail(value)){
                                throw new Error("invalid email id")
                        }
                }
        },
        password:{
                type:Number,
                required:true,
                minLength:8
        }
        
        
 })

 //we need a collection
 const Login = mongoose.model("Login", userSchema);

 module.exports =  Login;
